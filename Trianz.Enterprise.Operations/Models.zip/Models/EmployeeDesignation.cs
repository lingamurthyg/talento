﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Trianz.Enterprise.Operations.Models
{
    public class EmployeeDesignation
    {
        public string Designation { set; get; }
        public int Chicago { set; get; }
        public int SiliconValley { set; get; }
        public int Massachusetts { set; get; }
        public int Texas { set; get; }
        public int Hyderabad { set; get; }
        public int UnitedKingdom { set; get; }
        public int California { set; get; }
        public int Washington { set; get; }
        public int Virginia { set; get; }
        public int Bangalore { set; get; }
        public int NorthCarolina { set; get; }
        public int NewHampshire { set; get; }
        public int Mumbai { set; get; }
        public int Dubai { set; get; }
        public int RAK { set; get; }
        public int SVO { set; get; }
        public int NewJersey { set; get; }
        public int NewYork { set; get; }
        public int Noida { set; get; }
        public int Egypt { set; get; }
        public int Illinois { set; get; }
        public int Chennai { set; get; }
        public int UAE { set; get; }
        public int Sydney { set; get; }
    }
}



























