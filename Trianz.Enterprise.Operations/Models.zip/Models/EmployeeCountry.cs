﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Trianz.Enterprise.Operations.Models
{
    public class EmployeeCountry
    {
        public string GradeCode { set; get; }
        public int UnitedStates { set; get; }
        public int India { set; get; }
        public int UnitedKingdom { set; get; }
        public int Dubai { set; get; }
        public int Australia { set; get; }
        

    }
}